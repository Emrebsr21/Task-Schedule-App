﻿namespace Calemre
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.gunaMainPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.panelNewTask = new Guna.UI2.WinForms.Guna2Panel();
            this.buttonSaveTask = new System.Windows.Forms.Button();
            this.priority5 = new System.Windows.Forms.RadioButton();
            this.priority4 = new System.Windows.Forms.RadioButton();
            this.priority3 = new System.Windows.Forms.RadioButton();
            this.priority2 = new System.Windows.Forms.RadioButton();
            this.priority1 = new System.Windows.Forms.RadioButton();
            this.labelPriority = new System.Windows.Forms.Label();
            this.textDesc = new System.Windows.Forms.RichTextBox();
            this.labelDesc = new System.Windows.Forms.Label();
            this.textTaskName = new System.Windows.Forms.TextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panelTask4 = new Guna.UI2.WinForms.Guna2Panel();
            this.buttonSavePanel4 = new System.Windows.Forms.Button();
            this.priority25 = new System.Windows.Forms.RadioButton();
            this.priority24 = new System.Windows.Forms.RadioButton();
            this.priority23 = new System.Windows.Forms.RadioButton();
            this.priority22 = new System.Windows.Forms.RadioButton();
            this.priority21 = new System.Windows.Forms.RadioButton();
            this.labelPriorityPanel4 = new System.Windows.Forms.Label();
            this.descPanel4 = new System.Windows.Forms.RichTextBox();
            this.labelDescPanel4 = new System.Windows.Forms.Label();
            this.textPanel4 = new System.Windows.Forms.TextBox();
            this.datePanel4 = new System.Windows.Forms.DateTimePicker();
            this.panelTask3 = new Guna.UI2.WinForms.Guna2Panel();
            this.buttonSavePanel3 = new System.Windows.Forms.Button();
            this.priority20 = new System.Windows.Forms.RadioButton();
            this.priority19 = new System.Windows.Forms.RadioButton();
            this.priority18 = new System.Windows.Forms.RadioButton();
            this.priority17 = new System.Windows.Forms.RadioButton();
            this.priority16 = new System.Windows.Forms.RadioButton();
            this.labelPriorityPanel3 = new System.Windows.Forms.Label();
            this.descPanel3 = new System.Windows.Forms.RichTextBox();
            this.labelDescPanel3 = new System.Windows.Forms.Label();
            this.textPanel3 = new System.Windows.Forms.TextBox();
            this.datePanel3 = new System.Windows.Forms.DateTimePicker();
            this.panelTask2 = new Guna.UI2.WinForms.Guna2Panel();
            this.buttonSavePanel2 = new System.Windows.Forms.Button();
            this.priority15 = new System.Windows.Forms.RadioButton();
            this.priority14 = new System.Windows.Forms.RadioButton();
            this.priority13 = new System.Windows.Forms.RadioButton();
            this.priority12 = new System.Windows.Forms.RadioButton();
            this.priority11 = new System.Windows.Forms.RadioButton();
            this.labelPriorityPanel2 = new System.Windows.Forms.Label();
            this.descPanel2 = new System.Windows.Forms.RichTextBox();
            this.labelDescPanel2 = new System.Windows.Forms.Label();
            this.textPanel2 = new System.Windows.Forms.TextBox();
            this.datePanel2 = new System.Windows.Forms.DateTimePicker();
            this.panelPasswrodChange = new System.Windows.Forms.Panel();
            this.buttonCancelUpdate = new System.Windows.Forms.Button();
            this.buttonUpdatePsswd = new System.Windows.Forms.Button();
            this.labelNewPsswd = new System.Windows.Forms.Label();
            this.labelRetypePsswd = new System.Windows.Forms.Label();
            this.labelCurrentPsswd = new System.Windows.Forms.Label();
            this.textBoxNewPsswd = new System.Windows.Forms.TextBox();
            this.textBoxRetypePsswd = new System.Windows.Forms.TextBox();
            this.textBoxCurrentPsswd = new System.Windows.Forms.TextBox();
            this.panelTask1 = new Guna.UI2.WinForms.Guna2Panel();
            this.buttonSavePanel1 = new System.Windows.Forms.Button();
            this.priority10 = new System.Windows.Forms.RadioButton();
            this.priority9 = new System.Windows.Forms.RadioButton();
            this.priority8 = new System.Windows.Forms.RadioButton();
            this.priority7 = new System.Windows.Forms.RadioButton();
            this.priority6 = new System.Windows.Forms.RadioButton();
            this.labelPriorityPanel1 = new System.Windows.Forms.Label();
            this.descPanel1 = new System.Windows.Forms.RichTextBox();
            this.labelDescPanel1 = new System.Windows.Forms.Label();
            this.textPanel1 = new System.Windows.Forms.TextBox();
            this.datePanel1 = new System.Windows.Forms.DateTimePicker();
            this.gunaRightPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.buttonSignOut = new System.Windows.Forms.Button();
            this.buttonChangePassword = new System.Windows.Forms.Button();
            this.labelUsername = new System.Windows.Forms.Label();
            this.iconUser = new System.Windows.Forms.PictureBox();
            this.gunaLeftPanel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.iconEditTasks = new System.Windows.Forms.PictureBox();
            this.iconRemoveTasks = new System.Windows.Forms.PictureBox();
            this.iconAddTasks = new System.Windows.Forms.PictureBox();
            this.iconHome = new System.Windows.Forms.PictureBox();
            this.gunaMainPanel.SuspendLayout();
            this.panelNewTask.SuspendLayout();
            this.panelTask4.SuspendLayout();
            this.panelTask3.SuspendLayout();
            this.panelTask2.SuspendLayout();
            this.panelPasswrodChange.SuspendLayout();
            this.panelTask1.SuspendLayout();
            this.gunaRightPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconUser)).BeginInit();
            this.gunaLeftPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconEditTasks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconRemoveTasks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconAddTasks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconHome)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaMainPanel
            // 
            this.gunaMainPanel.BorderRadius = 20;
            this.gunaMainPanel.Controls.Add(this.panelNewTask);
            this.gunaMainPanel.Controls.Add(this.panelTask4);
            this.gunaMainPanel.Controls.Add(this.panelTask3);
            this.gunaMainPanel.Controls.Add(this.panelTask2);
            this.gunaMainPanel.Controls.Add(this.panelPasswrodChange);
            this.gunaMainPanel.Controls.Add(this.panelTask1);
            this.gunaMainPanel.Controls.Add(this.gunaRightPanel);
            this.gunaMainPanel.Controls.Add(this.gunaLeftPanel);
            this.gunaMainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gunaMainPanel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(27)))), ((int)(((byte)(33)))));
            this.gunaMainPanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(27)))), ((int)(((byte)(33)))));
            this.gunaMainPanel.Location = new System.Drawing.Point(10, 10);
            this.gunaMainPanel.Name = "gunaMainPanel";
            this.gunaMainPanel.Padding = new System.Windows.Forms.Padding(20);
            this.gunaMainPanel.Size = new System.Drawing.Size(1067, 564);
            this.gunaMainPanel.TabIndex = 0;
            // 
            // panelNewTask
            // 
            this.panelNewTask.Controls.Add(this.buttonSaveTask);
            this.panelNewTask.Controls.Add(this.priority5);
            this.panelNewTask.Controls.Add(this.priority4);
            this.panelNewTask.Controls.Add(this.priority3);
            this.panelNewTask.Controls.Add(this.priority2);
            this.panelNewTask.Controls.Add(this.priority1);
            this.panelNewTask.Controls.Add(this.labelPriority);
            this.panelNewTask.Controls.Add(this.textDesc);
            this.panelNewTask.Controls.Add(this.labelDesc);
            this.panelNewTask.Controls.Add(this.textTaskName);
            this.panelNewTask.Controls.Add(this.dateTimePicker);
            this.panelNewTask.Location = new System.Drawing.Point(632, 158);
            this.panelNewTask.Name = "panelNewTask";
            this.panelNewTask.Size = new System.Drawing.Size(240, 207);
            this.panelNewTask.TabIndex = 3;
            // 
            // buttonSaveTask
            // 
            this.buttonSaveTask.ForeColor = System.Drawing.Color.Teal;
            this.buttonSaveTask.Location = new System.Drawing.Point(64, 173);
            this.buttonSaveTask.Name = "buttonSaveTask";
            this.buttonSaveTask.Size = new System.Drawing.Size(101, 23);
            this.buttonSaveTask.TabIndex = 8;
            this.buttonSaveTask.Text = "Save Task";
            this.buttonSaveTask.UseVisualStyleBackColor = true;
            // 
            // priority5
            // 
            this.priority5.AutoSize = true;
            this.priority5.Location = new System.Drawing.Point(182, 148);
            this.priority5.Name = "priority5";
            this.priority5.Size = new System.Drawing.Size(38, 20);
            this.priority5.TabIndex = 9;
            this.priority5.TabStop = true;
            this.priority5.Text = "5";
            this.priority5.UseVisualStyleBackColor = true;
            // 
            // priority4
            // 
            this.priority4.AutoSize = true;
            this.priority4.Location = new System.Drawing.Point(138, 148);
            this.priority4.Name = "priority4";
            this.priority4.Size = new System.Drawing.Size(38, 20);
            this.priority4.TabIndex = 8;
            this.priority4.TabStop = true;
            this.priority4.Text = "4";
            this.priority4.UseVisualStyleBackColor = true;
            // 
            // priority3
            // 
            this.priority3.AutoSize = true;
            this.priority3.Location = new System.Drawing.Point(94, 148);
            this.priority3.Name = "priority3";
            this.priority3.Size = new System.Drawing.Size(38, 20);
            this.priority3.TabIndex = 7;
            this.priority3.TabStop = true;
            this.priority3.Text = "3";
            this.priority3.UseVisualStyleBackColor = true;
            // 
            // priority2
            // 
            this.priority2.AutoSize = true;
            this.priority2.Location = new System.Drawing.Point(50, 148);
            this.priority2.Name = "priority2";
            this.priority2.Size = new System.Drawing.Size(38, 20);
            this.priority2.TabIndex = 6;
            this.priority2.TabStop = true;
            this.priority2.Text = "2";
            this.priority2.UseVisualStyleBackColor = true;
            // 
            // priority1
            // 
            this.priority1.AutoSize = true;
            this.priority1.Location = new System.Drawing.Point(6, 148);
            this.priority1.Name = "priority1";
            this.priority1.Size = new System.Drawing.Size(38, 20);
            this.priority1.TabIndex = 5;
            this.priority1.TabStop = true;
            this.priority1.Text = "1";
            this.priority1.UseVisualStyleBackColor = true;
            // 
            // labelPriority
            // 
            this.labelPriority.AutoSize = true;
            this.labelPriority.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriority.Location = new System.Drawing.Point(3, 130);
            this.labelPriority.Name = "labelPriority";
            this.labelPriority.Size = new System.Drawing.Size(48, 15);
            this.labelPriority.TabIndex = 4;
            this.labelPriority.Text = "Priority";
            // 
            // textDesc
            // 
            this.textDesc.Location = new System.Drawing.Point(2, 80);
            this.textDesc.Name = "textDesc";
            this.textDesc.Size = new System.Drawing.Size(235, 47);
            this.textDesc.TabIndex = 3;
            this.textDesc.Text = "";
            // 
            // labelDesc
            // 
            this.labelDesc.AutoSize = true;
            this.labelDesc.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDesc.Location = new System.Drawing.Point(3, 62);
            this.labelDesc.Name = "labelDesc";
            this.labelDesc.Size = new System.Drawing.Size(74, 15);
            this.labelDesc.TabIndex = 2;
            this.labelDesc.Text = "Description";
            // 
            // textTaskName
            // 
            this.textTaskName.Location = new System.Drawing.Point(3, 0);
            this.textTaskName.Multiline = true;
            this.textTaskName.Name = "textTaskName";
            this.textTaskName.Size = new System.Drawing.Size(237, 26);
            this.textTaskName.TabIndex = 1;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Location = new System.Drawing.Point(101, 31);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(139, 26);
            this.dateTimePicker.TabIndex = 0;
            // 
            // panelTask4
            // 
            this.panelTask4.Controls.Add(this.buttonSavePanel4);
            this.panelTask4.Controls.Add(this.priority25);
            this.panelTask4.Controls.Add(this.priority24);
            this.panelTask4.Controls.Add(this.priority23);
            this.panelTask4.Controls.Add(this.priority22);
            this.panelTask4.Controls.Add(this.priority21);
            this.panelTask4.Controls.Add(this.labelPriorityPanel4);
            this.panelTask4.Controls.Add(this.descPanel4);
            this.panelTask4.Controls.Add(this.labelDescPanel4);
            this.panelTask4.Controls.Add(this.textPanel4);
            this.panelTask4.Controls.Add(this.datePanel4);
            this.panelTask4.Location = new System.Drawing.Point(371, 290);
            this.panelTask4.Name = "panelTask4";
            this.panelTask4.Size = new System.Drawing.Size(240, 207);
            this.panelTask4.TabIndex = 12;
            // 
            // buttonSavePanel4
            // 
            this.buttonSavePanel4.ForeColor = System.Drawing.Color.Teal;
            this.buttonSavePanel4.Location = new System.Drawing.Point(64, 173);
            this.buttonSavePanel4.Name = "buttonSavePanel4";
            this.buttonSavePanel4.Size = new System.Drawing.Size(101, 23);
            this.buttonSavePanel4.TabIndex = 8;
            this.buttonSavePanel4.Text = "Save Task";
            this.buttonSavePanel4.UseVisualStyleBackColor = true;
            // 
            // priority25
            // 
            this.priority25.AutoSize = true;
            this.priority25.Location = new System.Drawing.Point(182, 148);
            this.priority25.Name = "priority25";
            this.priority25.Size = new System.Drawing.Size(38, 20);
            this.priority25.TabIndex = 9;
            this.priority25.TabStop = true;
            this.priority25.Text = "5";
            this.priority25.UseVisualStyleBackColor = true;
            // 
            // priority24
            // 
            this.priority24.AutoSize = true;
            this.priority24.Location = new System.Drawing.Point(138, 148);
            this.priority24.Name = "priority24";
            this.priority24.Size = new System.Drawing.Size(38, 20);
            this.priority24.TabIndex = 8;
            this.priority24.TabStop = true;
            this.priority24.Text = "4";
            this.priority24.UseVisualStyleBackColor = true;
            // 
            // priority23
            // 
            this.priority23.AutoSize = true;
            this.priority23.Location = new System.Drawing.Point(94, 148);
            this.priority23.Name = "priority23";
            this.priority23.Size = new System.Drawing.Size(38, 20);
            this.priority23.TabIndex = 7;
            this.priority23.TabStop = true;
            this.priority23.Text = "3";
            this.priority23.UseVisualStyleBackColor = true;
            // 
            // priority22
            // 
            this.priority22.AutoSize = true;
            this.priority22.Location = new System.Drawing.Point(50, 148);
            this.priority22.Name = "priority22";
            this.priority22.Size = new System.Drawing.Size(38, 20);
            this.priority22.TabIndex = 6;
            this.priority22.TabStop = true;
            this.priority22.Text = "2";
            this.priority22.UseVisualStyleBackColor = true;
            // 
            // priority21
            // 
            this.priority21.AutoSize = true;
            this.priority21.Location = new System.Drawing.Point(6, 148);
            this.priority21.Name = "priority21";
            this.priority21.Size = new System.Drawing.Size(38, 20);
            this.priority21.TabIndex = 5;
            this.priority21.TabStop = true;
            this.priority21.Text = "1";
            this.priority21.UseVisualStyleBackColor = true;
            // 
            // labelPriorityPanel4
            // 
            this.labelPriorityPanel4.AutoSize = true;
            this.labelPriorityPanel4.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriorityPanel4.Location = new System.Drawing.Point(3, 130);
            this.labelPriorityPanel4.Name = "labelPriorityPanel4";
            this.labelPriorityPanel4.Size = new System.Drawing.Size(48, 15);
            this.labelPriorityPanel4.TabIndex = 4;
            this.labelPriorityPanel4.Text = "Priority";
            // 
            // descPanel4
            // 
            this.descPanel4.Location = new System.Drawing.Point(2, 80);
            this.descPanel4.Name = "descPanel4";
            this.descPanel4.Size = new System.Drawing.Size(235, 47);
            this.descPanel4.TabIndex = 3;
            this.descPanel4.Text = "";
            // 
            // labelDescPanel4
            // 
            this.labelDescPanel4.AutoSize = true;
            this.labelDescPanel4.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescPanel4.Location = new System.Drawing.Point(3, 62);
            this.labelDescPanel4.Name = "labelDescPanel4";
            this.labelDescPanel4.Size = new System.Drawing.Size(74, 15);
            this.labelDescPanel4.TabIndex = 2;
            this.labelDescPanel4.Text = "Description";
            // 
            // textPanel4
            // 
            this.textPanel4.Location = new System.Drawing.Point(3, 0);
            this.textPanel4.Multiline = true;
            this.textPanel4.Name = "textPanel4";
            this.textPanel4.Size = new System.Drawing.Size(237, 26);
            this.textPanel4.TabIndex = 1;
            // 
            // datePanel4
            // 
            this.datePanel4.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePanel4.Location = new System.Drawing.Point(101, 32);
            this.datePanel4.Name = "datePanel4";
            this.datePanel4.Size = new System.Drawing.Size(139, 26);
            this.datePanel4.TabIndex = 0;
            // 
            // panelTask3
            // 
            this.panelTask3.Controls.Add(this.buttonSavePanel3);
            this.panelTask3.Controls.Add(this.priority20);
            this.panelTask3.Controls.Add(this.priority19);
            this.panelTask3.Controls.Add(this.priority18);
            this.panelTask3.Controls.Add(this.priority17);
            this.panelTask3.Controls.Add(this.priority16);
            this.panelTask3.Controls.Add(this.labelPriorityPanel3);
            this.panelTask3.Controls.Add(this.descPanel3);
            this.panelTask3.Controls.Add(this.labelDescPanel3);
            this.panelTask3.Controls.Add(this.textPanel3);
            this.panelTask3.Controls.Add(this.datePanel3);
            this.panelTask3.Location = new System.Drawing.Point(112, 290);
            this.panelTask3.Name = "panelTask3";
            this.panelTask3.Size = new System.Drawing.Size(240, 207);
            this.panelTask3.TabIndex = 10;
            // 
            // buttonSavePanel3
            // 
            this.buttonSavePanel3.ForeColor = System.Drawing.Color.Teal;
            this.buttonSavePanel3.Location = new System.Drawing.Point(64, 173);
            this.buttonSavePanel3.Name = "buttonSavePanel3";
            this.buttonSavePanel3.Size = new System.Drawing.Size(101, 23);
            this.buttonSavePanel3.TabIndex = 8;
            this.buttonSavePanel3.Text = "Save Task";
            this.buttonSavePanel3.UseVisualStyleBackColor = true;
            // 
            // priority20
            // 
            this.priority20.AutoSize = true;
            this.priority20.Location = new System.Drawing.Point(182, 148);
            this.priority20.Name = "priority20";
            this.priority20.Size = new System.Drawing.Size(38, 20);
            this.priority20.TabIndex = 9;
            this.priority20.TabStop = true;
            this.priority20.Text = "5";
            this.priority20.UseVisualStyleBackColor = true;
            // 
            // priority19
            // 
            this.priority19.AutoSize = true;
            this.priority19.Location = new System.Drawing.Point(138, 148);
            this.priority19.Name = "priority19";
            this.priority19.Size = new System.Drawing.Size(38, 20);
            this.priority19.TabIndex = 8;
            this.priority19.TabStop = true;
            this.priority19.Text = "4";
            this.priority19.UseVisualStyleBackColor = true;
            // 
            // priority18
            // 
            this.priority18.AutoSize = true;
            this.priority18.Location = new System.Drawing.Point(94, 148);
            this.priority18.Name = "priority18";
            this.priority18.Size = new System.Drawing.Size(38, 20);
            this.priority18.TabIndex = 7;
            this.priority18.TabStop = true;
            this.priority18.Text = "3";
            this.priority18.UseVisualStyleBackColor = true;
            // 
            // priority17
            // 
            this.priority17.AutoSize = true;
            this.priority17.Location = new System.Drawing.Point(50, 148);
            this.priority17.Name = "priority17";
            this.priority17.Size = new System.Drawing.Size(38, 20);
            this.priority17.TabIndex = 6;
            this.priority17.TabStop = true;
            this.priority17.Text = "2";
            this.priority17.UseVisualStyleBackColor = true;
            // 
            // priority16
            // 
            this.priority16.AutoSize = true;
            this.priority16.Location = new System.Drawing.Point(6, 148);
            this.priority16.Name = "priority16";
            this.priority16.Size = new System.Drawing.Size(38, 20);
            this.priority16.TabIndex = 5;
            this.priority16.TabStop = true;
            this.priority16.Text = "1";
            this.priority16.UseVisualStyleBackColor = true;
            // 
            // labelPriorityPanel3
            // 
            this.labelPriorityPanel3.AutoSize = true;
            this.labelPriorityPanel3.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriorityPanel3.Location = new System.Drawing.Point(3, 130);
            this.labelPriorityPanel3.Name = "labelPriorityPanel3";
            this.labelPriorityPanel3.Size = new System.Drawing.Size(48, 15);
            this.labelPriorityPanel3.TabIndex = 4;
            this.labelPriorityPanel3.Text = "Priority";
            // 
            // descPanel3
            // 
            this.descPanel3.Location = new System.Drawing.Point(2, 80);
            this.descPanel3.Name = "descPanel3";
            this.descPanel3.Size = new System.Drawing.Size(235, 47);
            this.descPanel3.TabIndex = 3;
            this.descPanel3.Text = "";
            // 
            // labelDescPanel3
            // 
            this.labelDescPanel3.AutoSize = true;
            this.labelDescPanel3.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescPanel3.Location = new System.Drawing.Point(3, 62);
            this.labelDescPanel3.Name = "labelDescPanel3";
            this.labelDescPanel3.Size = new System.Drawing.Size(74, 15);
            this.labelDescPanel3.TabIndex = 2;
            this.labelDescPanel3.Text = "Description";
            // 
            // textPanel3
            // 
            this.textPanel3.Location = new System.Drawing.Point(3, 0);
            this.textPanel3.Multiline = true;
            this.textPanel3.Name = "textPanel3";
            this.textPanel3.Size = new System.Drawing.Size(237, 26);
            this.textPanel3.TabIndex = 1;
            // 
            // datePanel3
            // 
            this.datePanel3.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePanel3.Location = new System.Drawing.Point(105, 32);
            this.datePanel3.Name = "datePanel3";
            this.datePanel3.Size = new System.Drawing.Size(139, 26);
            this.datePanel3.TabIndex = 0;
            // 
            // panelTask2
            // 
            this.panelTask2.Controls.Add(this.buttonSavePanel2);
            this.panelTask2.Controls.Add(this.priority15);
            this.panelTask2.Controls.Add(this.priority14);
            this.panelTask2.Controls.Add(this.priority13);
            this.panelTask2.Controls.Add(this.priority12);
            this.panelTask2.Controls.Add(this.priority11);
            this.panelTask2.Controls.Add(this.labelPriorityPanel2);
            this.panelTask2.Controls.Add(this.descPanel2);
            this.panelTask2.Controls.Add(this.labelDescPanel2);
            this.panelTask2.Controls.Add(this.textPanel2);
            this.panelTask2.Controls.Add(this.datePanel2);
            this.panelTask2.Location = new System.Drawing.Point(374, 20);
            this.panelTask2.Name = "panelTask2";
            this.panelTask2.Size = new System.Drawing.Size(240, 207);
            this.panelTask2.TabIndex = 11;
            // 
            // buttonSavePanel2
            // 
            this.buttonSavePanel2.ForeColor = System.Drawing.Color.Teal;
            this.buttonSavePanel2.Location = new System.Drawing.Point(64, 173);
            this.buttonSavePanel2.Name = "buttonSavePanel2";
            this.buttonSavePanel2.Size = new System.Drawing.Size(101, 23);
            this.buttonSavePanel2.TabIndex = 8;
            this.buttonSavePanel2.Text = "Save Task";
            this.buttonSavePanel2.UseVisualStyleBackColor = true;
            // 
            // priority15
            // 
            this.priority15.AutoSize = true;
            this.priority15.Location = new System.Drawing.Point(182, 148);
            this.priority15.Name = "priority15";
            this.priority15.Size = new System.Drawing.Size(38, 20);
            this.priority15.TabIndex = 9;
            this.priority15.TabStop = true;
            this.priority15.Text = "5";
            this.priority15.UseVisualStyleBackColor = true;
            // 
            // priority14
            // 
            this.priority14.AutoSize = true;
            this.priority14.Location = new System.Drawing.Point(138, 148);
            this.priority14.Name = "priority14";
            this.priority14.Size = new System.Drawing.Size(38, 20);
            this.priority14.TabIndex = 8;
            this.priority14.TabStop = true;
            this.priority14.Text = "4";
            this.priority14.UseVisualStyleBackColor = true;
            // 
            // priority13
            // 
            this.priority13.AutoSize = true;
            this.priority13.Location = new System.Drawing.Point(94, 148);
            this.priority13.Name = "priority13";
            this.priority13.Size = new System.Drawing.Size(38, 20);
            this.priority13.TabIndex = 7;
            this.priority13.TabStop = true;
            this.priority13.Text = "3";
            this.priority13.UseVisualStyleBackColor = true;
            // 
            // priority12
            // 
            this.priority12.AutoSize = true;
            this.priority12.Location = new System.Drawing.Point(50, 148);
            this.priority12.Name = "priority12";
            this.priority12.Size = new System.Drawing.Size(38, 20);
            this.priority12.TabIndex = 6;
            this.priority12.TabStop = true;
            this.priority12.Text = "2";
            this.priority12.UseVisualStyleBackColor = true;
            // 
            // priority11
            // 
            this.priority11.AutoSize = true;
            this.priority11.Location = new System.Drawing.Point(6, 148);
            this.priority11.Name = "priority11";
            this.priority11.Size = new System.Drawing.Size(38, 20);
            this.priority11.TabIndex = 5;
            this.priority11.TabStop = true;
            this.priority11.Text = "1";
            this.priority11.UseVisualStyleBackColor = true;
            // 
            // labelPriorityPanel2
            // 
            this.labelPriorityPanel2.AutoSize = true;
            this.labelPriorityPanel2.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriorityPanel2.Location = new System.Drawing.Point(3, 130);
            this.labelPriorityPanel2.Name = "labelPriorityPanel2";
            this.labelPriorityPanel2.Size = new System.Drawing.Size(48, 15);
            this.labelPriorityPanel2.TabIndex = 4;
            this.labelPriorityPanel2.Text = "Priority";
            // 
            // descPanel2
            // 
            this.descPanel2.Location = new System.Drawing.Point(2, 80);
            this.descPanel2.Name = "descPanel2";
            this.descPanel2.Size = new System.Drawing.Size(235, 47);
            this.descPanel2.TabIndex = 3;
            this.descPanel2.Text = "";
            // 
            // labelDescPanel2
            // 
            this.labelDescPanel2.AutoSize = true;
            this.labelDescPanel2.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescPanel2.Location = new System.Drawing.Point(3, 62);
            this.labelDescPanel2.Name = "labelDescPanel2";
            this.labelDescPanel2.Size = new System.Drawing.Size(74, 15);
            this.labelDescPanel2.TabIndex = 2;
            this.labelDescPanel2.Text = "Description";
            // 
            // textPanel2
            // 
            this.textPanel2.Location = new System.Drawing.Point(3, 0);
            this.textPanel2.Multiline = true;
            this.textPanel2.Name = "textPanel2";
            this.textPanel2.Size = new System.Drawing.Size(237, 26);
            this.textPanel2.TabIndex = 1;
            // 
            // datePanel2
            // 
            this.datePanel2.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePanel2.Location = new System.Drawing.Point(107, 32);
            this.datePanel2.Name = "datePanel2";
            this.datePanel2.Size = new System.Drawing.Size(139, 26);
            this.datePanel2.TabIndex = 0;
            // 
            // panelPasswrodChange
            // 
            this.panelPasswrodChange.Controls.Add(this.buttonCancelUpdate);
            this.panelPasswrodChange.Controls.Add(this.buttonUpdatePsswd);
            this.panelPasswrodChange.Controls.Add(this.labelNewPsswd);
            this.panelPasswrodChange.Controls.Add(this.labelRetypePsswd);
            this.panelPasswrodChange.Controls.Add(this.labelCurrentPsswd);
            this.panelPasswrodChange.Controls.Add(this.textBoxNewPsswd);
            this.panelPasswrodChange.Controls.Add(this.textBoxRetypePsswd);
            this.panelPasswrodChange.Controls.Add(this.textBoxCurrentPsswd);
            this.panelPasswrodChange.Location = new System.Drawing.Point(833, 233);
            this.panelPasswrodChange.Name = "panelPasswrodChange";
            this.panelPasswrodChange.Size = new System.Drawing.Size(231, 276);
            this.panelPasswrodChange.TabIndex = 2;
            this.panelPasswrodChange.Visible = false;
            // 
            // buttonCancelUpdate
            // 
            this.buttonCancelUpdate.ForeColor = System.Drawing.Color.Teal;
            this.buttonCancelUpdate.Location = new System.Drawing.Point(131, 230);
            this.buttonCancelUpdate.Name = "buttonCancelUpdate";
            this.buttonCancelUpdate.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelUpdate.TabIndex = 7;
            this.buttonCancelUpdate.Text = "Cancel";
            this.buttonCancelUpdate.UseVisualStyleBackColor = true;
            // 
            // buttonUpdatePsswd
            // 
            this.buttonUpdatePsswd.ForeColor = System.Drawing.Color.Teal;
            this.buttonUpdatePsswd.Location = new System.Drawing.Point(24, 230);
            this.buttonUpdatePsswd.Name = "buttonUpdatePsswd";
            this.buttonUpdatePsswd.Size = new System.Drawing.Size(101, 23);
            this.buttonUpdatePsswd.TabIndex = 6;
            this.buttonUpdatePsswd.Text = "Update PSSWD";
            this.buttonUpdatePsswd.UseVisualStyleBackColor = true;
            // 
            // labelNewPsswd
            // 
            this.labelNewPsswd.AutoSize = true;
            this.labelNewPsswd.ForeColor = System.Drawing.Color.Teal;
            this.labelNewPsswd.Location = new System.Drawing.Point(22, 90);
            this.labelNewPsswd.Name = "labelNewPsswd";
            this.labelNewPsswd.Size = new System.Drawing.Size(113, 16);
            this.labelNewPsswd.TabIndex = 5;
            this.labelNewPsswd.Text = "New Password";
            // 
            // labelRetypePsswd
            // 
            this.labelRetypePsswd.AutoSize = true;
            this.labelRetypePsswd.ForeColor = System.Drawing.Color.Teal;
            this.labelRetypePsswd.Location = new System.Drawing.Point(22, 154);
            this.labelRetypePsswd.Name = "labelRetypePsswd";
            this.labelRetypePsswd.Size = new System.Drawing.Size(141, 16);
            this.labelRetypePsswd.TabIndex = 4;
            this.labelRetypePsswd.Text = "Confirm Password";
            // 
            // labelCurrentPsswd
            // 
            this.labelCurrentPsswd.AutoSize = true;
            this.labelCurrentPsswd.ForeColor = System.Drawing.Color.Teal;
            this.labelCurrentPsswd.Location = new System.Drawing.Point(22, 27);
            this.labelCurrentPsswd.Name = "labelCurrentPsswd";
            this.labelCurrentPsswd.Size = new System.Drawing.Size(138, 16);
            this.labelCurrentPsswd.TabIndex = 3;
            this.labelCurrentPsswd.Text = "Current Password";
            // 
            // textBoxNewPsswd
            // 
            this.textBoxNewPsswd.Location = new System.Drawing.Point(25, 109);
            this.textBoxNewPsswd.Name = "textBoxNewPsswd";
            this.textBoxNewPsswd.Size = new System.Drawing.Size(182, 29);
            this.textBoxNewPsswd.TabIndex = 2;
            // 
            // textBoxRetypePsswd
            // 
            this.textBoxRetypePsswd.Location = new System.Drawing.Point(25, 173);
            this.textBoxRetypePsswd.Name = "textBoxRetypePsswd";
            this.textBoxRetypePsswd.Size = new System.Drawing.Size(182, 29);
            this.textBoxRetypePsswd.TabIndex = 1;
            // 
            // textBoxCurrentPsswd
            // 
            this.textBoxCurrentPsswd.Location = new System.Drawing.Point(25, 46);
            this.textBoxCurrentPsswd.Name = "textBoxCurrentPsswd";
            this.textBoxCurrentPsswd.Size = new System.Drawing.Size(182, 29);
            this.textBoxCurrentPsswd.TabIndex = 0;
            // 
            // panelTask1
            // 
            this.panelTask1.Controls.Add(this.buttonSavePanel1);
            this.panelTask1.Controls.Add(this.priority10);
            this.panelTask1.Controls.Add(this.priority9);
            this.panelTask1.Controls.Add(this.priority8);
            this.panelTask1.Controls.Add(this.priority7);
            this.panelTask1.Controls.Add(this.priority6);
            this.panelTask1.Controls.Add(this.labelPriorityPanel1);
            this.panelTask1.Controls.Add(this.descPanel1);
            this.panelTask1.Controls.Add(this.labelDescPanel1);
            this.panelTask1.Controls.Add(this.textPanel1);
            this.panelTask1.Controls.Add(this.datePanel1);
            this.panelTask1.Location = new System.Drawing.Point(110, 20);
            this.panelTask1.Name = "panelTask1";
            this.panelTask1.Size = new System.Drawing.Size(240, 207);
            this.panelTask1.TabIndex = 10;
            // 
            // buttonSavePanel1
            // 
            this.buttonSavePanel1.ForeColor = System.Drawing.Color.Teal;
            this.buttonSavePanel1.Location = new System.Drawing.Point(64, 173);
            this.buttonSavePanel1.Name = "buttonSavePanel1";
            this.buttonSavePanel1.Size = new System.Drawing.Size(101, 23);
            this.buttonSavePanel1.TabIndex = 8;
            this.buttonSavePanel1.Text = "Save Task";
            this.buttonSavePanel1.UseVisualStyleBackColor = true;
            // 
            // priority10
            // 
            this.priority10.AutoSize = true;
            this.priority10.Location = new System.Drawing.Point(182, 148);
            this.priority10.Name = "priority10";
            this.priority10.Size = new System.Drawing.Size(38, 20);
            this.priority10.TabIndex = 9;
            this.priority10.TabStop = true;
            this.priority10.Text = "5";
            this.priority10.UseVisualStyleBackColor = true;
            // 
            // priority9
            // 
            this.priority9.AutoSize = true;
            this.priority9.Location = new System.Drawing.Point(138, 148);
            this.priority9.Name = "priority9";
            this.priority9.Size = new System.Drawing.Size(38, 20);
            this.priority9.TabIndex = 8;
            this.priority9.TabStop = true;
            this.priority9.Text = "4";
            this.priority9.UseVisualStyleBackColor = true;
            // 
            // priority8
            // 
            this.priority8.AutoSize = true;
            this.priority8.Location = new System.Drawing.Point(94, 148);
            this.priority8.Name = "priority8";
            this.priority8.Size = new System.Drawing.Size(38, 20);
            this.priority8.TabIndex = 7;
            this.priority8.TabStop = true;
            this.priority8.Text = "3";
            this.priority8.UseVisualStyleBackColor = true;
            // 
            // priority7
            // 
            this.priority7.AutoSize = true;
            this.priority7.Location = new System.Drawing.Point(50, 148);
            this.priority7.Name = "priority7";
            this.priority7.Size = new System.Drawing.Size(38, 20);
            this.priority7.TabIndex = 6;
            this.priority7.TabStop = true;
            this.priority7.Text = "2";
            this.priority7.UseVisualStyleBackColor = true;
            // 
            // priority6
            // 
            this.priority6.AutoSize = true;
            this.priority6.Location = new System.Drawing.Point(6, 148);
            this.priority6.Name = "priority6";
            this.priority6.Size = new System.Drawing.Size(38, 20);
            this.priority6.TabIndex = 5;
            this.priority6.TabStop = true;
            this.priority6.Text = "1";
            this.priority6.UseVisualStyleBackColor = true;
            // 
            // labelPriorityPanel1
            // 
            this.labelPriorityPanel1.AutoSize = true;
            this.labelPriorityPanel1.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriorityPanel1.Location = new System.Drawing.Point(3, 130);
            this.labelPriorityPanel1.Name = "labelPriorityPanel1";
            this.labelPriorityPanel1.Size = new System.Drawing.Size(48, 15);
            this.labelPriorityPanel1.TabIndex = 4;
            this.labelPriorityPanel1.Text = "Priority";
            // 
            // descPanel1
            // 
            this.descPanel1.Location = new System.Drawing.Point(2, 80);
            this.descPanel1.Name = "descPanel1";
            this.descPanel1.Size = new System.Drawing.Size(235, 47);
            this.descPanel1.TabIndex = 3;
            this.descPanel1.Text = "";
            // 
            // labelDescPanel1
            // 
            this.labelDescPanel1.AutoSize = true;
            this.labelDescPanel1.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescPanel1.Location = new System.Drawing.Point(3, 62);
            this.labelDescPanel1.Name = "labelDescPanel1";
            this.labelDescPanel1.Size = new System.Drawing.Size(74, 15);
            this.labelDescPanel1.TabIndex = 2;
            this.labelDescPanel1.Text = "Description";
            // 
            // textPanel1
            // 
            this.textPanel1.Location = new System.Drawing.Point(3, 0);
            this.textPanel1.Multiline = true;
            this.textPanel1.Name = "textPanel1";
            this.textPanel1.Size = new System.Drawing.Size(237, 26);
            this.textPanel1.TabIndex = 1;
            // 
            // datePanel1
            // 
            this.datePanel1.Font = new System.Drawing.Font("Bauhaus 93", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePanel1.Location = new System.Drawing.Point(101, 32);
            this.datePanel1.Name = "datePanel1";
            this.datePanel1.Size = new System.Drawing.Size(139, 26);
            this.datePanel1.TabIndex = 0;
            // 
            // gunaRightPanel
            // 
            this.gunaRightPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(27)))), ((int)(((byte)(33)))));
            this.gunaRightPanel.Controls.Add(this.buttonSignOut);
            this.gunaRightPanel.Controls.Add(this.buttonChangePassword);
            this.gunaRightPanel.Controls.Add(this.labelUsername);
            this.gunaRightPanel.Controls.Add(this.iconUser);
            this.gunaRightPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaRightPanel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(22)))), ((int)(((byte)(31)))));
            this.gunaRightPanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(22)))), ((int)(((byte)(31)))));
            this.gunaRightPanel.Location = new System.Drawing.Point(895, 20);
            this.gunaRightPanel.Name = "gunaRightPanel";
            this.gunaRightPanel.Size = new System.Drawing.Size(152, 524);
            this.gunaRightPanel.TabIndex = 1;
            // 
            // buttonSignOut
            // 
            this.buttonSignOut.ForeColor = System.Drawing.Color.Teal;
            this.buttonSignOut.Location = new System.Drawing.Point(-1, 104);
            this.buttonSignOut.Name = "buttonSignOut";
            this.buttonSignOut.Size = new System.Drawing.Size(153, 23);
            this.buttonSignOut.TabIndex = 9;
            this.buttonSignOut.Text = "Sign Out";
            this.buttonSignOut.UseVisualStyleBackColor = true;
            this.buttonSignOut.Click += new System.EventHandler(this.buttonSignOut_Click);
            // 
            // buttonChangePassword
            // 
            this.buttonChangePassword.ForeColor = System.Drawing.Color.Teal;
            this.buttonChangePassword.Location = new System.Drawing.Point(-4, 75);
            this.buttonChangePassword.Name = "buttonChangePassword";
            this.buttonChangePassword.Size = new System.Drawing.Size(153, 23);
            this.buttonChangePassword.TabIndex = 8;
            this.buttonChangePassword.Text = "Change Password";
            this.buttonChangePassword.UseVisualStyleBackColor = true;
            this.buttonChangePassword.Click += new System.EventHandler(this.buttonChangePassword_Click);
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.ForeColor = System.Drawing.Color.Teal;
            this.labelUsername.Location = new System.Drawing.Point(12, 50);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(118, 16);
            this.labelUsername.TabIndex = 3;
            this.labelUsername.Text = "labelUsername";
            // 
            // iconUser
            // 
            this.iconUser.Image = ((System.Drawing.Image)(resources.GetObject("iconUser.Image")));
            this.iconUser.Location = new System.Drawing.Point(46, 0);
            this.iconUser.Name = "iconUser";
            this.iconUser.Size = new System.Drawing.Size(48, 47);
            this.iconUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconUser.TabIndex = 2;
            this.iconUser.TabStop = false;
            // 
            // gunaLeftPanel
            // 
            this.gunaLeftPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(27)))), ((int)(((byte)(33)))));
            this.gunaLeftPanel.Controls.Add(this.iconEditTasks);
            this.gunaLeftPanel.Controls.Add(this.iconRemoveTasks);
            this.gunaLeftPanel.Controls.Add(this.iconAddTasks);
            this.gunaLeftPanel.Controls.Add(this.iconHome);
            this.gunaLeftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaLeftPanel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(22)))), ((int)(((byte)(31)))));
            this.gunaLeftPanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(22)))), ((int)(((byte)(31)))));
            this.gunaLeftPanel.Location = new System.Drawing.Point(20, 20);
            this.gunaLeftPanel.Name = "gunaLeftPanel";
            this.gunaLeftPanel.Size = new System.Drawing.Size(73, 524);
            this.gunaLeftPanel.TabIndex = 0;
            // 
            // iconEditTasks
            // 
            this.iconEditTasks.Image = ((System.Drawing.Image)(resources.GetObject("iconEditTasks.Image")));
            this.iconEditTasks.Location = new System.Drawing.Point(12, 138);
            this.iconEditTasks.Name = "iconEditTasks";
            this.iconEditTasks.Size = new System.Drawing.Size(48, 47);
            this.iconEditTasks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconEditTasks.TabIndex = 4;
            this.iconEditTasks.TabStop = false;
            // 
            // iconRemoveTasks
            // 
            this.iconRemoveTasks.Image = ((System.Drawing.Image)(resources.GetObject("iconRemoveTasks.Image")));
            this.iconRemoveTasks.Location = new System.Drawing.Point(12, 202);
            this.iconRemoveTasks.Name = "iconRemoveTasks";
            this.iconRemoveTasks.Size = new System.Drawing.Size(48, 47);
            this.iconRemoveTasks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconRemoveTasks.TabIndex = 3;
            this.iconRemoveTasks.TabStop = false;
            // 
            // iconAddTasks
            // 
            this.iconAddTasks.Image = ((System.Drawing.Image)(resources.GetObject("iconAddTasks.Image")));
            this.iconAddTasks.Location = new System.Drawing.Point(13, 75);
            this.iconAddTasks.Name = "iconAddTasks";
            this.iconAddTasks.Size = new System.Drawing.Size(48, 47);
            this.iconAddTasks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconAddTasks.TabIndex = 1;
            this.iconAddTasks.TabStop = false;
            this.iconAddTasks.Click += new System.EventHandler(this.iconAddTasks_Click);
            // 
            // iconHome
            // 
            this.iconHome.Image = ((System.Drawing.Image)(resources.GetObject("iconHome.Image")));
            this.iconHome.Location = new System.Drawing.Point(13, 13);
            this.iconHome.Name = "iconHome";
            this.iconHome.Size = new System.Drawing.Size(48, 47);
            this.iconHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconHome.TabIndex = 0;
            this.iconHome.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(22)))), ((int)(((byte)(31)))));
            this.ClientSize = new System.Drawing.Size(1087, 584);
            this.Controls.Add(this.gunaMainPanel);
            this.Font = new System.Drawing.Font("Bauhaus 93", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.gunaMainPanel.ResumeLayout(false);
            this.panelNewTask.ResumeLayout(false);
            this.panelNewTask.PerformLayout();
            this.panelTask4.ResumeLayout(false);
            this.panelTask4.PerformLayout();
            this.panelTask3.ResumeLayout(false);
            this.panelTask3.PerformLayout();
            this.panelTask2.ResumeLayout(false);
            this.panelTask2.PerformLayout();
            this.panelPasswrodChange.ResumeLayout(false);
            this.panelPasswrodChange.PerformLayout();
            this.panelTask1.ResumeLayout(false);
            this.panelTask1.PerformLayout();
            this.gunaRightPanel.ResumeLayout(false);
            this.gunaRightPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconUser)).EndInit();
            this.gunaLeftPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconEditTasks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconRemoveTasks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconAddTasks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconHome)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel gunaMainPanel;
        private Guna.UI2.WinForms.Guna2GradientPanel gunaLeftPanel;
        private System.Windows.Forms.PictureBox iconUser;
        private System.Windows.Forms.PictureBox iconAddTasks;
        private System.Windows.Forms.PictureBox iconHome;
        private Guna.UI2.WinForms.Guna2GradientPanel gunaRightPanel;
        private System.Windows.Forms.PictureBox iconEditTasks;
        private System.Windows.Forms.PictureBox iconRemoveTasks;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Panel panelPasswrodChange;
        private System.Windows.Forms.TextBox textBoxNewPsswd;
        private System.Windows.Forms.TextBox textBoxRetypePsswd;
        private System.Windows.Forms.TextBox textBoxCurrentPsswd;
        private System.Windows.Forms.Label labelCurrentPsswd;
        private System.Windows.Forms.Label labelNewPsswd;
        private System.Windows.Forms.Label labelRetypePsswd;
        private System.Windows.Forms.Button buttonCancelUpdate;
        private System.Windows.Forms.Button buttonUpdatePsswd;
        private System.Windows.Forms.Button buttonChangePassword;
        private System.Windows.Forms.Button buttonSignOut;
        private Guna.UI2.WinForms.Guna2Panel panelNewTask;
        private System.Windows.Forms.TextBox textTaskName;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.RadioButton priority5;
        private System.Windows.Forms.RadioButton priority4;
        private System.Windows.Forms.RadioButton priority3;
        private System.Windows.Forms.RadioButton priority2;
        private System.Windows.Forms.RadioButton priority1;
        private System.Windows.Forms.Label labelPriority;
        private System.Windows.Forms.RichTextBox textDesc;
        private System.Windows.Forms.Label labelDesc;
        private System.Windows.Forms.Button buttonSaveTask;
        private Guna.UI2.WinForms.Guna2Panel panelTask1;
        private System.Windows.Forms.Button buttonSavePanel1;
        private System.Windows.Forms.RadioButton priority10;
        private System.Windows.Forms.RadioButton priority9;
        private System.Windows.Forms.RadioButton priority8;
        private System.Windows.Forms.RadioButton priority7;
        private System.Windows.Forms.RadioButton priority6;
        private System.Windows.Forms.Label labelPriorityPanel1;
        private System.Windows.Forms.RichTextBox descPanel1;
        private System.Windows.Forms.Label labelDescPanel1;
        private System.Windows.Forms.DateTimePicker datePanel1;
        private System.Windows.Forms.TextBox textPanel1;
        private Guna.UI2.WinForms.Guna2Panel panelTask4;
        private System.Windows.Forms.Button buttonSavePanel4;
        private System.Windows.Forms.RadioButton priority25;
        private System.Windows.Forms.RadioButton priority24;
        private System.Windows.Forms.RadioButton priority23;
        private System.Windows.Forms.RadioButton priority22;
        private System.Windows.Forms.RadioButton priority21;
        private System.Windows.Forms.Label labelPriorityPanel4;
        private System.Windows.Forms.RichTextBox descPanel4;
        private System.Windows.Forms.Label labelDescPanel4;
        private System.Windows.Forms.TextBox textPanel4;
        private System.Windows.Forms.DateTimePicker datePanel4;
        private Guna.UI2.WinForms.Guna2Panel panelTask3;
        private System.Windows.Forms.Button buttonSavePanel3;
        private System.Windows.Forms.RadioButton priority20;
        private System.Windows.Forms.RadioButton priority19;
        private System.Windows.Forms.RadioButton priority18;
        private System.Windows.Forms.RadioButton priority17;
        private System.Windows.Forms.RadioButton priority16;
        private System.Windows.Forms.Label labelPriorityPanel3;
        private System.Windows.Forms.RichTextBox descPanel3;
        private System.Windows.Forms.Label labelDescPanel3;
        private System.Windows.Forms.TextBox textPanel3;
        private System.Windows.Forms.DateTimePicker datePanel3;
        private Guna.UI2.WinForms.Guna2Panel panelTask2;
        private System.Windows.Forms.Button buttonSavePanel2;
        private System.Windows.Forms.RadioButton priority15;
        private System.Windows.Forms.RadioButton priority14;
        private System.Windows.Forms.RadioButton priority13;
        private System.Windows.Forms.RadioButton priority12;
        private System.Windows.Forms.RadioButton priority11;
        private System.Windows.Forms.Label labelPriorityPanel2;
        private System.Windows.Forms.RichTextBox descPanel2;
        private System.Windows.Forms.Label labelDescPanel2;
        private System.Windows.Forms.TextBox textPanel2;
        private System.Windows.Forms.DateTimePicker datePanel2;
    }
}